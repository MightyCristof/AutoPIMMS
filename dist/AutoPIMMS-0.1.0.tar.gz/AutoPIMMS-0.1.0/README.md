# AutoPIMMS
Upload tool for WebPIMMS designed for multiple queries.

May need to install mechanize to use:
https://github.com/python-mechanize/mechanize
